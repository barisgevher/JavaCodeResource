package dev.lpa.game;

public interface Player {

    String name();
}
