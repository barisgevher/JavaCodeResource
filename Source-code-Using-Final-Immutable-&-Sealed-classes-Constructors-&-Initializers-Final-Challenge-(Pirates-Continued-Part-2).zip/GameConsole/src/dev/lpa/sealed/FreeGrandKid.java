package dev.lpa.sealed;

public class FreeGrandKid extends NonSealedKid {
}
