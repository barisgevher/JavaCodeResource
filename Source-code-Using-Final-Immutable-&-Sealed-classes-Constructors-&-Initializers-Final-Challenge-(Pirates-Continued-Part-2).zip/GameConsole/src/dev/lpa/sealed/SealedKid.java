package dev.lpa.sealed;

public sealed class SealedKid extends SpecialAbstractClass {

    final class GrandKid extends SealedKid {

    }

}
